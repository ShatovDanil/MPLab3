﻿#include <iostream>
#include <cmath>

using namespace std;

double calculateArea(double sides[])
{
    double a = sides[0];
    double b = sides[1];
    double c = sides[2];

    double s = (a + b + c) / 2.0;
    double area = sqrt(s * (s - a) * (s - b) * (s - c));

    return area;
}

int main()
{
    double sides[3] = { 5.0, 6.0, 7.0 }; // массив сторон треугольника (здесь заданы произвольные значения)

    double area = calculateArea(sides);

    cout << "Square: " << area << endl;

    return 0;
}